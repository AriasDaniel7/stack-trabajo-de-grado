import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-P4GNISSK.js";
import "./chunk-3EVLEYEM.js";
export default require_cjs();
