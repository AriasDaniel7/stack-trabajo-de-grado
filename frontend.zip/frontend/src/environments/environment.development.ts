export const environment = {
  apiUrl: 'http://localhost:3000/api',
  production: false,
};
