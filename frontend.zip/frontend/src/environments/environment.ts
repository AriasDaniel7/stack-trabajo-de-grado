export const environment = {
  apiUrl: 'https://api.danielariaspruebas.site/api',
  production: true,
};
