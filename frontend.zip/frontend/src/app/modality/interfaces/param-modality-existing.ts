import { PaginationOptions } from '@core/interfaces/pagination';

export interface ParamModalityExisting extends PaginationOptions {
  idEducationalLevel: number;
}
