export interface ModalityResponse {
  id: number;
  descripcion: string;
  nivelEducativoId: number;
  puntos: null | string;
  codigo: null | string;
}
