export interface EducationLevel {
  id: number;
  descripcion: string;
  paraIes: string;
  observacion: null;
}
