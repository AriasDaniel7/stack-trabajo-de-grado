export interface MethodologyResponse {
  id: number;
  descripcion: string;
  activo: string;
}
